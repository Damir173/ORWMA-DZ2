package com.example.zadaca_2_basic;

public interface NameButtonClick {
    void onNameClick(int position);
}
