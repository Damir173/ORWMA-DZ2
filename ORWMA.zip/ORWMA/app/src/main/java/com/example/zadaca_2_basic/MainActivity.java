package com.example.zadaca_2_basic;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NameButtonClick{
    private RecyclerView recycler;
    private RecyclerAdapter Adapter;

    private EditText newNameText;
    private Button newNameButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupRecycler();
        setupRecyclerData();

        this.newNameText=(EditText)findViewById(R.id.edit_text);
        this.newNameButton=(Button)findViewById(R.id.tipka_add);
    }
    private void setupRecycler(){
        recycler=findViewById(R.id.rvLista);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        Adapter= new RecyclerAdapter(this);
        recycler.setAdapter(Adapter);
    }

    private void setupRecyclerData(){
        List<String> data = new ArrayList<>();
        data.add("Ivica");
        data.add("Petar");
        data.add("Filip");
        data.add("Ivana");
        data.add("Blaženka");
        data.add("Ivica");
        data.add("Petar");
        data.add("Filip");
        data.add("Ivana");
        data.add("Petar");
        data.add("Filip");
        data.add("Ivana");
        data.add("Blaženka");
        data.add("Ivica");
        data.add("Petar");
        data.add("Filip");
        data.add("Ivana");
        data.add("Blaženka");
        data.add("Ivica");
        data.add("Petar");
        data.add("Filip");
        data.add("Ivana");
        data.add("Blaženka");




        Adapter.addData(data);
    }

    public void addCell(View view){
        Adapter.addNewCell(newNameText.getText().toString(), this.Adapter.getItemCount());
    }

    public void removeCell(int position) {
        Adapter.removeCell(position);
    }


    @Override
    public void onNameClick(int position){
        //Toast.makeText(this, "pozicija"+position, Toast.LENGTH_SHORT).show();
        removeCell(position);
    }
}